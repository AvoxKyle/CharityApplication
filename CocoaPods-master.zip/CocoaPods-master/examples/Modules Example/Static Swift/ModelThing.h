//
//  ModelThing.h
//  Static Swift
//
//  Created by Samuel Giddins on 1/23/18.
//  Copyright © 2018 Samuel Giddins. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ModelThing : NSObject

+ (instancetype)copy;

@end

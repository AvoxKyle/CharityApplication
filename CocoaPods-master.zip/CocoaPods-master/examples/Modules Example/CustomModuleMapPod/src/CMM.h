#import <CustomModuleMapPod/CMMFunctions.h>
@import Foundation;

@interface CMM : NSObject
+ (void)log;
@end

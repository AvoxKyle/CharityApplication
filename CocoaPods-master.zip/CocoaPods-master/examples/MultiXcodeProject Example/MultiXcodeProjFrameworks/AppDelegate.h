//
//  AppDelegate.h
//  MultiXcodeProjFrameworks
//
//  Created by Sebastian Edward Shanus on 11/9/18.
//  Copyright © 2018 CocoaPods. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


import Cocoa
import HeaderMappingsDirPod
import HeaderMappingsDirPod.Private

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    @IBOutlet weak var window: NSWindow!
}


module Pod
  module VersionMetadata
    def self.gem_version
      Pod::VERSION
    end
  end
end

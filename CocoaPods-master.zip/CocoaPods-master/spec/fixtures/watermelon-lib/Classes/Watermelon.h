
#import <Foundation/Foundation.h>

/** Watermelons are cool */
@interface WatermelonObj : NSObject
@end

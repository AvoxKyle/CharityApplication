
#import <Foundation/Foundation.h>

/** Grapefruits are cool */
@interface Grapefruit : NSObject
@end

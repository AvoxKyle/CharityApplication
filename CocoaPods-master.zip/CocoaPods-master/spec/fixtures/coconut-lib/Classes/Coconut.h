
#import <Foundation/Foundation.h>

/** Coconuts are cool */
@interface CoconutObj : NSObject
@end
